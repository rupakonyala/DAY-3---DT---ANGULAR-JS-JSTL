package com.musichub.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
	public class LoginController 
{
	@RequestMapping("login")
	
	public ModelAndView LoginFunc(
			@RequestParam(value="uname", required=false, defaultValue="world") String name)
	{
		System.out.println("in controller");

			ModelAndView mv=new ModelAndView("login");
			mv.addObject("name",name);

			return mv;
			
			}
				
	@RequestMapping("register")	
	public ModelAndView RegFunc(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name){
			
			ModelAndView mv=new ModelAndView("register");
			
			mv.addObject("name", name);
			return mv;
			
			}
	/*	@RequestMapping("productinfo")
	public String m2()
	{
		return "productinfo";
		
	}*/
		
		@RequestMapping("/productinfo")
		public @ResponseBody ModelAndView thumbnails(
				@RequestParam(value = "artist", required = false, defaultValue = "A. R. Rahman") String artist,
				@RequestParam(value = "album", required = false, defaultValue = "BOLLY") String album,
				@RequestParam(value="quantity", required=false,defaultValue="1")String quantity,
				@RequestParam(value = "price", required = false, defaultValue = "World") String price
				) {
			System.out.println("in controller");
	 
			ModelAndView mv = new ModelAndView("productinfo");
			
			mv.addObject("artist", artist);
			mv.addObject("album",album);
			mv.addObject("quatity",quantity);
			mv.addObject("price",price);
			
			
			return mv;
			
		}
		
		@RequestMapping("/allproducts")
		public ModelAndView allproductsinfo(
				@RequestParam(value = "names", required = false, defaultValue = "World") String names) {
			System.out.println("in controller");	 
			ModelAndView mv = new ModelAndView("allproducts");			
			mv.addObject(names);
		
			return mv;
		}
		

	}


